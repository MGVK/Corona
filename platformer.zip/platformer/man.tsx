<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="man" tilewidth="32" tileheight="64" tilecount="1" columns="1">
 <image source="man.png" width="32" height="64"/>
</tileset>

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="genericPlatformer" tilewidth="32" tileheight="32" tilecount="144" columns="8">
 <image source="../maptest/tiles/genericPlatformer.png" width="256" height="576"/>
</tileset>
